package com.programacionFuncional.persistence.controller;

import com.programacionFuncional.persistence.entity.HybridResults;
import com.programacionFuncional.persistence.entity.Jobs;
import com.programacionFuncional.persistence.service.IJobs;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;

@RestController // Esta anotación indica que la clase es un controlador de Spring MVC y que cada método en la clase representa un punto final de la API REST.
@RequestMapping("/api/v1/jobs_salaries") // Esta anotación especifica la raíz del URI para todas las solicitudes manejadas por este controlador. En este caso, todas las rutas comenzarán con "/api/v1/jobs_salaries".
@RequiredArgsConstructor //sta es una anotación de Lombok que genera un constructor con todos los campos que son final. En este caso, se utiliza para inyectar automáticamente la dependencia iJobs en el constructor de la clase.
@Log4j2 // Esta anotación de Lombok genera un objeto de registro llamado log basado en Log4j2. Se utiliza para realizar registros de mensajes en la aplicación.
public class JobsController {


    @Autowired // Esta anotación se utiliza para la inyección de dependencias. En este caso, se utiliza para inyectar una instancia de IJobs en el controlador.
    private final IJobs iJobs;



    @CrossOrigin(origins = "http://localhost:4200") //Esta anotación permite solicitudes desde el origen especificado (http://localhost:4200). Es indispensable para la conexion de las peticiones hechas del fronted.
    @GetMapping("/countRegisters")
    public ResponseEntity<?> countRegister() {
        log.info("Question 1");
        Optional<Long> count = Optional.ofNullable(iJobs.sizeListJobs());
        return count.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null)); // Retorna una respuesta HTTP OK (200) con el tamaño de la lista como cuerpo de la respuesta.
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/salaryMin")
    public ResponseEntity<?> salaryMin() {
        log.info("Question 2");
        Optional<Double> salaryMin = Optional.ofNullable(iJobs.minimumSalary());
        return salaryMin.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/salaryMax")
    public ResponseEntity<?> salaryMax() {
        log.info("Question 3");
        Optional<Double> salaryMax = Optional.ofNullable(iJobs.maximumSalary());
        return salaryMax.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/listTitleWorks")
    public ResponseEntity<?> listWorks() {
        log.info("Question 4");
        Optional<List<String>> titlePopular = Optional.ofNullable(iJobs.listTitleWorks());
        return titlePopular.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/listEmployeeResidence")
    public ResponseEntity<?> listResidence() {
        log.info("Question 5");
        Optional<List<String>> residenceList = Optional.ofNullable(iJobs.listEmployeeResidence());
        return residenceList.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/totalResidenceEU")
    public ResponseEntity<?> totalResidenceEU() {
        log.info("Question 6");
        Optional<Long> eu = Optional.ofNullable(iJobs.totalResidenceEU());
        return eu.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/salaryEspecific")
    public ResponseEntity<?> salaryMin50k() {
        log.info("Question 7");
        Optional<Double> s50k = Optional.ofNullable(iJobs.showSalary());
        return s50k.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/listPeopleNotWork2023")
    public ResponseEntity<?> findNot2023() {
        log.info("Question 8");
        Optional<List<Jobs>> lstJ = Optional.ofNullable(iJobs.listPeopleNotWork());
        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/limitPeopleTen")
    public ResponseEntity<?> limitTen() {
        log.info("Question 9");
        Optional<List<Jobs>> lstJ = Optional.ofNullable(iJobs.limitPeople());
        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/findAllJobs")
    public ResponseEntity<?> findAll() {
        log.info("Question 10");
        Optional<List<Jobs>> lstJ = Optional.ofNullable(iJobs.findAllJobs());
        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/averageSalary")
    public ResponseEntity<?> average() {
        log.info("Question 11");
        Optional<OptionalDouble> lstJ = Optional.ofNullable(iJobs.averageSalary());
        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/averageSalarySenior")
    public ResponseEntity<?> averageSenior() {
        log.info("Question 12");
        Optional<OptionalDouble> lstJ = Optional.ofNullable(iJobs.averageSalarySenior());
        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/firstAnySalary")
    public ResponseEntity<?> findAnySalary() {
        log.info("Question 13");
        Optional<Double> lstJ = Optional.ofNullable(iJobs.firstSalary());
        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/avgSalaryCompany/{letter}")
    public ResponseEntity<?> findAnySalary(@PathVariable("letter") String letter) {
        log.info("Question 14");
        Optional<OptionalDouble> lstJ = Optional.ofNullable(iJobs.averageSalaryByCompany(letter));
        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/sumUSD/{limite}")
    public ResponseEntity<?> sumUsd(@PathVariable("limite") Integer limite) {
        log.info("Question 15");
        Optional<Double> lstJ = Optional.ofNullable(iJobs.sumSalaryUSDByLimit(limite));
        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/sumSalaryRange/{limite}")
    public ResponseEntity<?> findAnySalary(@PathVariable("limite") Integer maximo) {
        log.info("Question 16");
        Optional<OptionalDouble> lstJ = Optional.ofNullable(iJobs.sumSalaryByRange(maximo));
        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/findFirstWorkConf/{type}")
    public ResponseEntity<?> findFirstWork(@PathVariable("type") String conf) {
        log.info("Question 17");
        Optional<Optional<Jobs>> lstJ = Optional.ofNullable(iJobs.findWorkSettingAleatory(conf));

        return lstJ.map(result -> result.map(ResponseEntity::ok)
                        .orElseGet(() -> ResponseEntity.notFound().build()))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/calculatePortion")
    public ResponseEntity<?> calculatePortion() {
        log.info("Question 18");
        Optional<Double> lstJ = Optional.ofNullable(iJobs.calculatePortion());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/calculatePortionInPerson")
    public ResponseEntity<?> calculatePortionPerson() {
        log.info("Question 19");
        Optional<Double> lstJ = Optional.ofNullable(iJobs.calculatePortionInPerson());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/averageSalaryHybrid")
    public ResponseEntity<?> listHybridAndAverageSalary() {
        log.info("Question 20");
        Optional<HybridResults> lstJ = Optional.ofNullable(iJobs.averageSalaryHybrid());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/jobsBeetweenSalary")
    public ResponseEntity<?> listBeetwenSalary() {
        log.info("Question 21");
        Optional<List<Jobs>> lstJ = Optional.ofNullable(iJobs.jobsBeetweenSalary());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/sumPortionHybridAndPerson")
    public ResponseEntity<?> sumPortions() {
        log.info("Question 22");
        Optional<Double> lstJ = Optional.ofNullable(iJobs.sumPortionHybridAndPerson());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/highestSalaryPersonJobByLoc")
    public ResponseEntity<?> highestSalaryPersonJobByLoc() {
        log.info("Question 23");
        Optional<Map<String, Jobs>> lstJ = Optional.ofNullable(iJobs.highestSalaryPersonJobByLoc());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/locWithHighestSalaryVarForHybJobs")
    public ResponseEntity<?> locWithHighestSalaryVarForHybJobs() {
        log.info("Question 24");
        Optional<Map<String, Double>> lstJ = Optional.ofNullable(iJobs.locWithHighestSalaryVarForHybJobs());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/highPayingHybridJobsForTitle")
    public ResponseEntity<?> highPayingHybridJobsForTitle() {
        log.info("Question 25");
        Optional<List<Jobs>> lstJ = Optional.ofNullable(iJobs.highPayingHybridJobsForTitle());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/highestSalaryInPerson")
    public ResponseEntity<?> highestSalaryInPerson() {
        log.info("Question 26");
        Optional<Map<String, Jobs>> lstJ = Optional.ofNullable(iJobs.highestSalaryInPerson());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/hybridJobsWithAtLeastMLevel")
    public ResponseEntity<?> hybridJobsWithAtLeastMLevel() {
        log.info("Question 27");
        Optional<List<Jobs>> lstJ = Optional.ofNullable(iJobs.hybridJobsWithAtLeastMLevel());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/hybridJobsWithSpecificYearOrderedBySalaryDesc")
    public ResponseEntity<?> hybridJobsWithSpecificYearOrderedBySalaryDesc() {
        log.info("Question 28");
        Optional<List<Jobs>> lstJ = Optional.ofNullable(iJobs.hybridJobsWithSpecificYearOrderedBySalaryDesc());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/jobsWithSalaryInRangeOrderedByResidence/{salarioMin}/{salarioMax}")
    public ResponseEntity<?> jobsWithSalaryInRangeOrderedByResidence(@PathVariable("salarioMin") double salaryMin, @PathVariable("salarioMax") double salaryMax) {
        log.info("Question 29");
        Optional<List<Jobs>> lstJ = Optional.ofNullable(iJobs.jobsWithSalaryInRangeOrderedByResidence(salaryMin, salaryMax));

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/jobsWithUniqueSalariesAndDistinctExperienceLevels")
    public ResponseEntity<?> jobsWithUniqueSalariesAndDistinctExperienceLevels() {
        log.info("Question 30");
        Optional<List<Jobs>> lstJ = Optional.ofNullable(iJobs.jobsWithUniqueSalariesAndDistinctExperienceLevels());

        return lstJ.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

}







