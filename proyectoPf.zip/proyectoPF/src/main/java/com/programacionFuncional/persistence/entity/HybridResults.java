package com.programacionFuncional.persistence.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;
@Data //Esta notacion de spring, genera los getters y setters de la clase
@AllArgsConstructor //Esta notacion de spring, genera el constructor de la clase
public class HybridResults {
    private List<Jobs> hybridJobs;
    private double averageSalary;


}
