package com.programacionFuncional.persistence.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data //Esta notacion de spring, genera los getters y setters de la clase
@AllArgsConstructor //Esta notacion de spring, genera el constructor de la clase
public class Jobs {
    private String work_year;
    private String job_title;
    private String job_category;
    private String salary_currency;
    private Double salary;
    private Double salary_in_usd;
    private String employee_residence;
    private String experience_level;
    private String employment_type;
    private String work_setting;
    private String company_location;
    private String company_size;



}
