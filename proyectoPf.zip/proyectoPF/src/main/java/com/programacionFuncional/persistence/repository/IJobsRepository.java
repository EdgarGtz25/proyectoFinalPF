package com.programacionFuncional.persistence.repository;

import com.programacionFuncional.persistence.entity.Jobs;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
@Repository //En el contexto de persistencia de datos en Spring, un "repositorio" es típicamente una clase
// que maneja el acceso y la manipulación de datos, especialmente cuando se trabaja con bases de datos
public class IJobsRepository {
    private static final String SEPARADOR = ",";
    private final String ruta;

    public IJobsRepository(@Value("${ruta.archivo}") String ruta) {
        this.ruta = ruta;
    }

    public List<Jobs> obtenerRegistros() {
        Path path = Path.of(ruta);
        try {
            return Files.lines(path)
                    .skip(1) // Saltar la primera línea si contiene encabezados
                    .map(linea -> linea.split(SEPARADOR))
                    .map(this::maperJobs)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            // Manejar la excepción apropiadamente
            e.printStackTrace(); // O usa un logger para registrar la excepción
            return Collections.emptyList(); // o lanza una excepción personalizada o retorna un valor predeterminado
        }
    }

    private Jobs maperJobs(String[] campos) {
        try {
            // Adaptación de atributos para la clase Jobs
            String work_year = campos.length > 0 && !campos[0].isEmpty() ? campos[0] : "Unknown";
            String job_title = campos.length > 1 && !campos[1].isEmpty() ? campos[1] : "Unknown";
            String job_category = campos.length > 2 && !campos[2].isEmpty() ? campos[2] : "Unknown";
            String salary_currency = campos.length > 3 && !campos[3].isEmpty() ? campos[3] : "Unknown";
            Double salary = campos.length > 4 && !campos[4].isEmpty() ? Double.parseDouble(campos[4]) : 0.0;
            Double salary_in_usd = campos.length > 5 && !campos[5].isEmpty() ? Double.parseDouble(campos[5]) : 0.0;
            String employee_residence = campos.length > 6 && !campos[6].isEmpty() ? campos[6] : "Unknown";
            String experience_level = campos.length > 7 && !campos[7].isEmpty() ? campos[7] : "Unknown";
            String employment_type = campos.length > 8 && !campos[8].isEmpty() ? campos[8] : "Unknown";
            String work_setting = campos.length > 9 && !campos[9].isEmpty() ? campos[9] : "Unknown";
            String company_location = campos.length > 10 && !campos[10].isEmpty() ? campos[10] : "Unknown";
            String company_size = campos.length > 11 && !campos[11].isEmpty() ? campos[11] : "Unknown";
            return new Jobs(work_year, job_title, job_category, salary_currency, salary, salary_in_usd, employee_residence, experience_level, employment_type,
                    work_setting, company_location, company_size);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return null;

        }

    }
}
