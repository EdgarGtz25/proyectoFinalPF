package com.programacionFuncional.persistence.service;

import com.programacionFuncional.persistence.entity.HybridResults;
import com.programacionFuncional.persistence.entity.Jobs;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;

public interface IJobs {
    public Long sizeListJobs();
    public Double minimumSalary();
    public Double maximumSalary();
    public List<String> listTitleWorks();
    public List<String> listEmployeeResidence();
    public Long totalResidenceEU();
    public Double showSalary();
    public List<Jobs> findAllJobs();
    public List<Jobs> listPeopleNotWork();
    public List<Jobs> limitPeople();
    public OptionalDouble averageSalary();
    public OptionalDouble averageSalarySenior();
    public Double firstSalary();
    public OptionalDouble averageSalaryByCompany(String letter);
    public Double sumSalaryUSDByLimit(Integer limite);
    public OptionalDouble sumSalaryByRange(Integer maximo);
    public Optional<Jobs> findWorkSettingAleatory(String work);
    public Double calculatePortion();
    public Double calculatePortionInPerson();
    public HybridResults averageSalaryHybrid();
    public List<Jobs> jobsBeetweenSalary();
    public Double sumPortionHybridAndPerson();
    public Map<String,Jobs> highestSalaryPersonJobByLoc();
    public Map<String,Double> locWithHighestSalaryVarForHybJobs();
    public List<Jobs> highPayingHybridJobsForTitle();
    public Map<String,Jobs> highestSalaryInPerson();
    public List<Jobs> hybridJobsWithAtLeastMLevel();
    public List<Jobs> hybridJobsWithSpecificYearOrderedBySalaryDesc();
    public List<Jobs> jobsWithSalaryInRangeOrderedByResidence(double salarioMin,double salarioMax);
    public List<Jobs> jobsWithUniqueSalariesAndDistinctExperienceLevels();
}
