package com.programacionFuncional.persistence.serviceImpl;

import com.programacionFuncional.persistence.entity.HybridResults;
import com.programacionFuncional.persistence.entity.Jobs;
import com.programacionFuncional.persistence.repository.IJobsRepository;
import com.programacionFuncional.persistence.service.IJobs;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service //n servicio en Spring generalmente encapsula la lógica de negocio y proporciona servicios específicos en una aplicación
@Log4j2
public class IJobsImpl implements IJobs {

    @Autowired //Inyeccion del repositorio
    private IJobsRepository iJobsRepository;

    // Método privado para obtener la lista de trabajos desde el repositorio
    private List<Jobs> getJobsList() {
        return iJobsRepository.obtenerRegistros();
    }

    // Implementación de la interfaz IJobs

    // Método para obtener el tamaño de la lista de trabajos
    @Override
    public Long sizeListJobs() {
        log.info("Finding results");
        List<Jobs> lstJobs = getJobsList();
        Long count = lstJobs.stream().count();
        return count;
    }

    // Método para obtener el salario mínimo
    @Override
    public Double minimumSalary() {
        log.info("Finding minimum");
        List<Jobs> lstJobs = getJobsList();
        return lstJobs.stream()
                .map(Jobs::getSalary)
                .min(Double::compare)
                .orElse(null);
    }

    // Método para obtener el salario máximo
    @Override
    public Double maximumSalary() {
        log.info("Finding salary maximum");
        List<Jobs> lstJobs = getJobsList();
        List<Double> salaryMax = lstJobs.stream()
                .map(Jobs::getSalary)
                .collect(Collectors.toList());

        Double maxSalary = salaryMax.stream()
                .max(Double::compare)
                .orElse(null);

        return maxSalary;
    }

    // Método para obtener la lista de títulos de trabajo sin repetir
    @Override
    public List<String> listTitleWorks() {
        List<Jobs> lstJobs = getJobsList();
        List<String> worksTitle = lstJobs.stream()
                .map(Jobs::getJob_title)
                .distinct()
                .collect(Collectors.toList());

        return worksTitle;
    }

    // Método para obtener la lista de residencias registradas
    @Override
    public List<String> listEmployeeResidence() {
        List<Jobs> lstJobs = getJobsList();
        List<String> residenceList = lstJobs.stream()
                .map(Jobs::getEmployee_residence)
                .distinct()
                .collect(Collectors.toList());
        return residenceList;
    }

    // Método para obtener el total de trabajos en EU
    @Override
    public Long totalResidenceEU() {
        List<Jobs> lstJobs = getJobsList();
        Long totalEU = lstJobs.stream()
                .filter(eu -> "United States".equals(eu.getEmployee_residence()))
                .count();

        return totalEU;
    }

    // Método para mostrar un salario específico
    @Override
    public Double showSalary() {
        List<Jobs> lstJobs = getJobsList();
        Double valor = lstJobs.stream()
                .filter(jobs -> jobs.getSalary_in_usd() < 100000)
                .findAny()
                .map(Jobs::getSalary_in_usd)
                .orElse(0.0);  // Proporciona un valor predeterminado si no se encuentra ningún elemento
        return valor;
    }

    // Método para obtener todos los trabajos
    @Override
    public List<Jobs> findAllJobs() {
        List<Jobs> lstJobs = getJobsList();
        return lstJobs.stream()
                .collect(Collectors.toList());
    }

    // Método para obtener personas que no trabajaron en el año 2023
    @Override
    public List<Jobs> listPeopleNotWork() {
        List<Jobs> lstJobs = getJobsList();
        List<Jobs> peopleNotWork = lstJobs.stream()
                .filter(eu -> !"2023".equalsIgnoreCase(eu.getWork_year()))
                .collect(Collectors.toList());
        return peopleNotWork;
    }

    // Método para limitar la cantidad de trabajos
    @Override
    public List<Jobs> limitPeople() {
        List<Jobs> lstJobs = getJobsList();
        List<Jobs> limitResult = lstJobs.stream()
                .limit(10).collect(Collectors.toList());
        return limitResult;
    }

    // Método para obtener el salario promedio
    @Override
    public OptionalDouble averageSalary() {
        List<Jobs> lstJobs = getJobsList();
        OptionalDouble promedio = lstJobs.stream()
                .mapToDouble(e -> e.getSalary()) // Convierte a IntStream
                .average(); // Calcula el promedio
        if (promedio.isPresent()) {
            System.out.println("El promedio de salario es: " + promedio.getAsDouble());
        } else {
            System.out.println("No se encontraron salarios para calcular el promedio.");
        }
        return promedio;
    }

    // Método para obtener el salario promedio de empleados senior
    @Override
    public OptionalDouble averageSalarySenior() {
        List<Jobs> lstJobs = getJobsList();
        List<Jobs> salariosSenior = lstJobs.stream()
                .filter(eu -> "Senior".equals(eu.getExperience_level()))
                .collect(Collectors.toList());
        OptionalDouble salarioPromedio = salariosSenior.stream()
                .mapToDouble(e -> e.getSalary_in_usd())
                .average();
        return salarioPromedio;
    }

    // Método para obtener el primer salario
    @Override
    public Double firstSalary() {
        log.info("Finding first salary");
        List<Jobs> lstJobs = getJobsList();
        List<Double> salaryMax = lstJobs.stream()
                .map(Jobs::getSalary)
                .collect(Collectors.toList());

        Double firstSalary = salaryMax.stream()
                .findAny()
                .orElse(null);

        return firstSalary;
    }

    // Método para obtener el salario promedio por tamaño de empresa
    @Override
    public OptionalDouble averageSalaryByCompany(String letter) {
        List<Jobs> lstJobs = getJobsList();
        List<Jobs> salariosByCompany = lstJobs.stream()
                .filter(eu -> letter.equals(eu.getCompany_size()))
                .collect(Collectors.toList());
        OptionalDouble salarioPromedio = salariosByCompany.stream()
                .mapToDouble(e -> e.getSalary_in_usd())
                .average();
        return salarioPromedio;
    }

    // Método para sumar salarios en USD dentro de un límite
    @Override
    public Double sumSalaryUSDByLimit(Integer limite) {
        List<Jobs> lstJobs = getJobsList();

        // Utiliza stream para filtrar trabajos basados en el límite y luego suma los salarios
        Double limitResult = lstJobs.stream()
                .limit(limite) // Aplica el límite
                .mapToDouble(Jobs::getSalary_in_usd) // Mapea a double para los salarios
                .sum(); // Suma los salarios

        return limitResult;
    }

    // Método para obtener la suma de salarios dentro de un rango
    @Override
    public OptionalDouble sumSalaryByRange(Integer maximo) {
        List<Jobs> lstJobs = getJobsList();
        List<Jobs> salariosByRange = lstJobs.stream()
                .filter(eu -> eu.getSalary() < maximo)
                .collect(Collectors.toList());
        OptionalDouble salarioPromedio = salariosByRange.stream()
                .mapToDouble(e -> e.getSalary())
                .average();
        return salarioPromedio;
    }

    // Método para encontrar un trabajo aleatorio
    @Override
    public Optional<Jobs> findWorkSettingAleatory(String form) {
        List<Jobs> lstJobs = getJobsList();

        Collections.shuffle(lstJobs); // Desordena la lista

        Optional<Jobs> trabajoAleatorio = lstJobs.stream()
                .filter(n -> n.getWork_setting().equals(form))
                .findFirst();

        return trabajoAleatorio;
    }

    // Método para calcular el porcentaje de trabajos remotos
    @Override
    public Double calculatePortion() {
        List<Jobs> lst = getJobsList();

        long totalJobs = lst.stream()
                .count();

        long remoteJobs = lst.stream()
                .filter(e -> e.getWork_setting().equals("Remote"))
                .count();

        Double porcentaje = Double.valueOf((remoteJobs * 100) / totalJobs);
        return porcentaje;
    }

    // Método para calcular el porcentaje de trabajos en persona
    @Override
    public Double calculatePortionInPerson() {
        List<Jobs> lst = getJobsList();

        long totalJobs = lst.stream()
                .count();

        long inPersonJobs = lst.stream()
                .filter(e -> e.getWork_setting().equals("In-person"))
                .count();

        Double porcentaje = Double.valueOf((inPersonJobs * 100) / totalJobs);
        return porcentaje;
    }

    // Método para obtener resultados híbridos (lista de trabajos híbridos y salario promedio)
    @Override
    public HybridResults averageSalaryHybrid() {
        List<Jobs> lst = getJobsList();

        // Filtra la lista para obtener solo los trabajos con configuración "Hybrid"
        List<Jobs> hybridJobs = lst.stream()
                .filter(e -> e.getWork_setting().equals("Hybrid"))
                .collect(Collectors.toList());

        // Calcula el salario promedio de los trabajos híbridos
        double promedioSalarios = hybridJobs.stream()
                .mapToDouble(Jobs::getSalary)
                .average()
                .orElse(0.0);  // Si no hay elementos, se establece el valor predeterminado en 0.0

        // Calcula el porcentaje en relación con la lista original
        long totalJobs = hybridJobs.size();
        double porcentaje = (hybridJobs.size() * 100.0) / totalJobs;
        System.out.println("Porcentaje en relación con la lista original: " + porcentaje + "%");

        // Devuelve los resultados como un objeto HybridResults
        return new HybridResults(hybridJobs, promedioSalarios);
    }

    // Método para obtener trabajos con salarios en un rango específico
    @Override
    public List<Jobs> jobsBeetweenSalary() {
        List<Jobs> lst = getJobsList();
        List<Jobs> lista = lst.stream()
                .filter(job -> job.getSalary() >= 100000 && job.getSalary() <= 125000)
                .collect(Collectors.toList());
        return lista;
    }

    // Método para obtener la suma de porcentajes de trabajos híbridos y en persona
    @Override
    public Double sumPortionHybridAndPerson() {
        Double porcion1 = calculatePortion();
        Double porcion2 = calculatePortionInPerson();
        Double porcionTotal = porcion1 + porcion2;
        return porcionTotal;
    }

    // Método para obtener el trabajo con el salario más alto por residencia del empleado para trabajos en persona
    @Override
    public Map<String, Jobs> highestSalaryPersonJobByLoc() {
        List<Jobs> jobsList = getJobsList();

        return jobsList.stream()
                .filter(job -> job.getWork_setting().equals("In-person"))
                .collect(Collectors.groupingBy(Jobs::getEmployee_residence,
                        Collectors.collectingAndThen(
                                Collectors.maxBy(Comparator.comparingDouble(Jobs::getSalary)),
                                Optional::get)));
    }

    // Método para obtener la variabilidad de salarios por ubicación para trabajos híbridos
    @Override
    public Map<String, Double> locWithHighestSalaryVarForHybJobs() {
        List<Jobs> jobsList = getJobsList();

        return jobsList.stream()
                .filter(job -> job.getWork_setting().equals("Hybrid"))
                .collect(Collectors.groupingBy(Jobs::getEmployee_residence,
                        Collectors.collectingAndThen(
                                Collectors.collectingAndThen(
                                        Collectors.toList(),
                                        jobs -> jobs.stream().mapToDouble(Jobs::getSalary).max().orElse(0.0)
                                                - jobs.stream().mapToDouble(Jobs::getSalary).min().orElse(0.0)),
                                variability -> variability > 0.0 ? variability : 0.0)));
    }

    // Método para obtener trabajos híbridos bien remunerados para un título específico
    @Override
    public List<Jobs> highPayingHybridJobsForTitle() {
        List<Jobs> jobsList = getJobsList();

        // Define el título de trabajo deseado
        String desiredJobTitle = "Data Scientist";

        // Calcula el salario promedio
        double averageSalary = jobsList.stream()
                .filter(job -> job.getWork_setting().equals("Hybrid"))
                .mapToDouble(Jobs::getSalary)
                .average()
                .orElse(0.0);

        // Filtra y devuelve los trabajos que cumplen con los criterios
        return jobsList.stream()
                .filter(job -> job.getWork_setting().equals("Hybrid") &&
                        job.getJob_title().equals(desiredJobTitle) &&
                        job.getSalary() > averageSalary)
                .collect(Collectors.toList());
    }

    // Método para obtener el trabajo en persona con el salario más alto por ubicación de la empresa
    @Override
    public Map<String, Jobs> highestSalaryInPerson() {
        List<Jobs> jobsList = getJobsList();

        return jobsList.stream()
                .filter(job -> job.getWork_setting().equals("In-person"))
                .collect(Collectors.groupingBy(Jobs::getCompany_location,
                        Collectors.collectingAndThen(
                                Collectors.maxBy(Comparator.comparingDouble(Jobs::getSalary)),
                                Optional::get)));
    }
    // Método para obtener trabajos híbridos con al menos nivel M
    @Override
    public List<Jobs> hybridJobsWithAtLeastMLevel() {
        List<Jobs> jobsList = getJobsList();
        // Definir el nivel de experiencia deseado
        String level = "Mid-level";
        return jobsList.stream()
                .filter(job -> job.getWork_setting().equals("Hybrid") &&
                        job.getExperience_level().equals(level))
                .collect(Collectors.toList());
    }

    // Método para obtener trabajos híbridos con habilidades específicas ordenados por salario descendente
    @Override
    public List<Jobs> hybridJobsWithSpecificYearOrderedBySalaryDesc() {
        List<Jobs> jobsList = getJobsList();

        return jobsList.stream()
                .filter(job -> job.getWork_setting().equals("Hybrid") &&
                        job.getWork_year().equals("2021"))
                .sorted(Comparator.comparingDouble(Jobs::getSalary).reversed())
                .collect(Collectors.toList());
    }

    // Método para obtener trabajos con salario en un rango ordenados por residencia
    @Override
    public List<Jobs> jobsWithSalaryInRangeOrderedByResidence(double salarioMin, double salarioMax) {
        List<Jobs> jobsList = getJobsList();

        return jobsList.stream()
                .filter(job -> job.getSalary() >= salarioMin && job.getSalary() <= salarioMax)
                .sorted(Comparator.comparing(Jobs::getEmployee_residence))
                .collect(Collectors.toList());
    }

    // Método para obtener trabajos con salarios únicos y niveles de experiencia distintos
    @Override
    public List<Jobs> jobsWithUniqueSalariesAndDistinctExperienceLevels() {
        List<Jobs> jobsList = getJobsList();

        return jobsList.stream()
                .collect(Collectors.groupingBy(Jobs::getSalary,
                        Collectors.mapping(Jobs::getExperience_level, Collectors.toSet())))
                .entrySet().stream()
                .filter(entry -> entry.getValue().size() > 1) // Filtrar salarios únicos y niveles de experiencia distintos
                .flatMap(entry -> jobsList.stream()
                        .filter(job -> job.getSalary() == entry.getKey() && entry.getValue().contains(job.getExperience_level())))
                .collect(Collectors.toList());
    }

}