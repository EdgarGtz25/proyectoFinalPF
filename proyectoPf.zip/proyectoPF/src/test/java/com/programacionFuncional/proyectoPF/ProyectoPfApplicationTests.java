package com.programacionFuncional.proyectoPF;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoPfApplicationTests {

	@Test
	void contextLoads() {
	}

}
